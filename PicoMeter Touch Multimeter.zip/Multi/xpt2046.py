"""
xpt2046.py – XPT2046 Dokunmatik Kontrolcü Sürücüsü
Pico 2 GPIO Pin Haritası (SPI1 paylaşımlı):
  T_CLK  → GP10  (Pin 14)  SPI1 SCK ile ortak
  T_DIN  → GP11  (Pin 15)  SPI1 MOSI ile ortak
  T_DO   → GP12  (Pin 16)  SPI1 MISO ile ortak
  T_CS   → GP15  (Pin 20)  Ayrı chip select

Ekran Modu: Landscape 320 × 240
Kalibrasyon Değerleri: Modüle göre ayarlanabilir.
"""

import time


class XPT2046:
    """
    XPT2046 12-bit dokunmatik ADC sürücüsü.
    ILI9341 ile aynı SPI veri yolunu paylaşır; CS pinleri ayrıdır.

    Kullanım:
        touch = XPT2046(spi, cs_pin)
        pt    = touch.get_touch()   # None veya (x, y) döner
    """

    # ─── Kalibrasyon Sabitleri (Landscape 320×240) ───────────────────────────
    # Bu değerleri dokunmatik kalibrasyon scriptiyle ince ayar yapın.
    RAW_X_MIN = 300    # Ekranın sol kenarındaki ham X değeri
    RAW_X_MAX = 3700   # Ekranın sağ kenarındaki ham X değeri
    RAW_Y_MIN = 320    # Ekranın üst kenarındaki ham Y değeri
    RAW_Y_MAX = 3750   # Ekranın alt kenarındaki ham Y değeri

    # XPT2046 Komut Byte'ları (SER/DFR=0, MODE=12-bit)
    CMD_X    = 0xD0    # X pozisyonu oku (PD=0b00 → ADC aktif)
    CMD_Y    = 0x90    # Y pozisyonu oku
    CMD_Z1   = 0xB0    # Dokunma basıncı Z1
    CMD_Z2   = 0xC0    # Dokunma basıncı Z2
    CMD_TEMP = 0x84    # Sıcaklık (opsiyonel)

    # ─── Dokunma Eşik Değerleri ───────────────────────────────────────────────
    Z_THRESHOLD  = 400    # Bu değerin üzerindeki Z değerleri dokunma sayılır
    SAMPLES      = 5      # Ortalama alma için örnek sayısı
    DEADZONE     = 60     # Ham değerlerde filtre ölü bandı

    def __init__(self, spi, cs, width=320, height=240):
        self.spi    = spi
        self.cs     = cs
        self.width  = width
        self.height = height
        self._rx_buf = bytearray(3)

    def _raw_read(self, cmd):
        """12-bit ADC değeri oku (3 byte SPI: 1 komut + 2 yanıt)."""
        buf = bytearray(3)
        buf[0] = cmd
        self.cs.value(0)
        self.spi.write_readinto(buf, buf)
        self.cs.value(1)
        # Yanıt: buf[1] (MSB, bit7-0) + buf[2] (LSB, bit7-3)
        return ((buf[1] << 8) | buf[2]) >> 3

    def _read_avg(self, cmd):
        """SAMPLES adet okuma yapıp min/max atarak ortalama hesapla."""
        vals = [self._raw_read(cmd) for _ in range(self.SAMPLES)]
        vals.sort()
        # Minimum ve maksimumu at (outlier azaltma)
        trimmed = vals[1:-1]
        return sum(trimmed) // len(trimmed)

    def _is_pressed(self):
        """Basınç (Z) değerine göre dokunma var mı?"""
        z1 = self._raw_read(self.CMD_Z1)
        z2 = self._raw_read(self.CMD_Z2)
        # Baskı katsayısı: daha yüksek z1 ve daha düşük z2 = güçlü dokunma
        pressure = z1 - z2 + 4095
        return pressure > self.Z_THRESHOLD

    def get_raw(self):
        """
        Ham (kalibrasyon uygulanmamış) dokunma koordinatları döner.
        Dokunma yoksa None döner. Kalibrasyon için kullanın.
        """
        if not self._is_pressed():
            return None
        rx = self._read_avg(self.CMD_X)
        ry = self._read_avg(self.CMD_Y)
        # Çok kenardaki değerleri filtrele (gürültü)
        if rx < 100 or rx > 4000 or ry < 100 or ry > 4000:
            return None
        return rx, ry

    def get_touch(self):
        """
        Kalibre edilmiş ekran koordinatları döner: (x, y).
        Dokunma yoksa None döner.
        x: 0 … width-1
        y: 0 … height-1
        """
        if not self._is_pressed():
            return None

        rx = self._read_avg(self.CMD_X)
        ry = self._read_avg(self.CMD_Y)

        # Sınır filtresi
        if rx < 100 or rx > 4000 or ry < 100 or ry > 4000:
            return None

        # --- YENİ EKSEN HARİTALAMASI (SWAP & INVERT) ---
        # ry, X eksenini kontrol ediyor (Soldan sağa artıyor)
        px = (ry - self.RAW_Y_MIN) * self.width // (self.RAW_Y_MAX - self.RAW_Y_MIN)
        
        # rx, Y eksenini kontrol ediyor (Aşağıdan yukarıya artıyor, Ters Çeviriyoruz: 240 - Y)
        py = 240 - ((rx - self.RAW_X_MIN) * self.height // (self.RAW_X_MAX - self.RAW_X_MIN))

        px = max(0, min(self.width  - 1, px))
        py = max(0, min(self.height - 1, py))

        return px, py

    def wait_touch(self, timeout_ms=5000):
        """
        Dokunma gerçekleşene kadar bekler.
        timeout_ms: Maksimum bekleme süresi (ms)
        Dokunma pozisyonunu veya timeout'ta None döner.
        """
        deadline = time.ticks_add(time.ticks_ms(), timeout_ms)
        while time.ticks_diff(deadline, time.ticks_ms()) > 0:
            pt = self.get_touch()
            if pt:
                return pt
            time.sleep_ms(10)
        return None

    def calibrate(self):
        """
        Konsola kalibrasyon değerlerini yazdırmak için basit yardımcı.
        Seri konsolu (REPL) üzerinden çalıştırın:
            from xpt2046 import XPT2046
            t = XPT2046(spi, touch_cs)
            t.calibrate()
        """
        import sys
        print("== XPT2046 Kalibrasyon ==")
        corners = [
            ("SOL ÜST  köşeye dokunun", "sol_ust"),
            ("SAĞ ÜST  köşeye dokunun", "sag_ust"),
            ("SOL ALT  köşeye dokunun", "sol_alt"),
            ("SAĞ ALT  köşeye dokunun", "sag_alt"),
        ]
        results = {}
        for msg, key in corners:
            print(f"\n{msg} (5 sn içinde)…")
            time.sleep_ms(1000)
            raw = self.wait_touch(5000)
            if raw:
                results[key] = raw
                print(f"  → Ham: {raw}")
            else:
                print("  → Dokunma alınamadı!")

        if len(results) == 4:
            x_min = min(results['sol_ust'][0], results['sol_alt'][0])
            x_max = max(results['sag_ust'][0], results['sag_alt'][0])
            y_min = min(results['sol_ust'][1], results['sag_ust'][1])
            y_max = max(results['sol_alt'][1], results['sag_alt'][1])
            print(f"\n# xpt2046.py içine bu değerleri yazın:")
            print(f"RAW_X_MIN = {x_min}")
            print(f"RAW_X_MAX = {x_max}")
            print(f"RAW_Y_MIN = {y_min}")
            print(f"RAW_Y_MAX = {y_max}")
