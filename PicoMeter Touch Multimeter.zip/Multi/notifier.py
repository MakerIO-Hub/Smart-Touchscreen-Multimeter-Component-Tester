"""
notifier.py – LED & Buzzer Notification Layer
========================================================================
Pico 2 GPIO Pin Map:
  Red   LED (Volt Mode)    → GP2  (Pin 4)
  Green LED (Component)    → GP3  (Pin 5)
  Blue  LED (Current Mode) → GP1  (Pin 2)
  Buzzer Signal (S)        → GP22 (Pin 29)
  Buzzer VCC (+)           → VSYS (Pin 39)
  Buzzer GND (-)           → GND  (Pin 18)
"""

import machine
import time

MODE_VOLT    = 'VOLT'
MODE_DIODE   = 'DIODE'
MODE_CURRENT = 'CURRENT'

class Notifier:

    def __init__(self, pin_red=2, pin_green=3, pin_blue=1, pin_buzzer=22):
        self.led_red   = machine.Pin(pin_red,   machine.Pin.OUT, value=0)
        self.led_green = machine.Pin(pin_green, machine.Pin.OUT, value=0)
        self.led_blue  = machine.Pin(pin_blue,  machine.Pin.OUT, value=0)

        # Buzzer: 0V = sessiz, 3.3V = öter (Active-HIGH)
        self._buz = machine.Pin(pin_buzzer, machine.Pin.OUT, value=0)
        self._buzzer_on = False
        self._current_mode = None

    # ── LED ──
    def _all_leds_off(self):
        self.led_red.value(0)
        self.led_green.value(0)
        self.led_blue.value(0)

    def set_mode(self, mode):
        if mode == self._current_mode:
            return
        self._current_mode = mode
        self._all_leds_off()
        if mode == MODE_VOLT:
            self.led_red.value(1)
        elif mode == MODE_DIODE:
            self.led_green.value(1)
        elif mode == MODE_CURRENT:
            self.led_blue.value(1)

    # ── Buzzer ──
    def _on(self):
        self._buz.value(1)
        self._buzzer_on = True

    def _off(self):
        self._buz.value(0)
        self._buzzer_on = False

    def beep(self, freq=2000, duration_ms=80):
        self._on()
        time.sleep_ms(duration_ms)
        self._off()

    def beep_ok(self):
        self.beep(2000, 60)
        time.sleep_ms(30)
        self.beep(2000, 90)

    def beep_diode(self, vf=0.6):
        self.beep(2000, 100)

    def beep_error(self):
        self.beep(2000, 80)
        time.sleep_ms(60)
        self.beep(2000, 80)

    def short_circuit_alarm(self):
        self._on()
        self.led_red.value(1)

    def stop_alarm(self):
        self._off()
        prev = self._current_mode
        self._current_mode = None
        self.set_mode(prev or MODE_VOLT)

    @property
    def alarm_active(self):
        return self._buzzer_on

    def startup_sequence(self):
        self.beep(2000, 200)
        time.sleep_ms(100)
        for led in [self.led_red, self.led_green, self.led_blue]:
            led.value(1)
            time.sleep_ms(80)
            led.value(0)
            time.sleep_ms(40)
        self.beep_ok()
