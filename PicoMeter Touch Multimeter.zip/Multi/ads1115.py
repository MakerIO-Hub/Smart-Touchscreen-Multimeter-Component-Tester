"""
ads1115.py – ADS1115 16-bit I2C ADC Sürücüsü
Pico 2 GPIO Pin Haritası (I2C0):
  SDA  → GP16  (Pin 21)
  SCL  → GP17  (Pin 22)
  VDD  → 3.3V  (Pin 36)
  GND  → GND   (Pin 38 / Pin 23)  ADDR pini de GND → I2C adres = 0x48

Kanal Atamaları:
  A0 → 100kΩ/10kΩ gerilim bölücü üzerinden DC Volt (0–30V)
  A1 → ACS712 çıkışı (5A/20A akım ölçümü)
  A2 → Diyot / Kısa Devre ölçüm hattı
  A3 → (Rezerve / Güç hesabı için)
"""

import time


# ─── Sabitler ───────────────────────────────────────────────────────────────
ADS1115_ADDR_GND  = 0x48   # ADDR=GND
ADS1115_ADDR_VCC  = 0x49   # ADDR=VDD
ADS1115_ADDR_SDA  = 0x4A   # ADDR=SDA
ADS1115_ADDR_SCL  = 0x4B   # ADDR=SCL

# Kayıt adresleri
REG_CONVERT = 0x00
REG_CONFIG  = 0x01
REG_LO_THR = 0x02
REG_HI_THR = 0x03

# Multiplexer (MUX) seçimi – Tek uçlu ölçüm (AGND referanslı)
MUX_AIN0 = 0x4000   # A0 - AGND
MUX_AIN1 = 0x5000   # A1 - AGND
MUX_AIN2 = 0x6000   # A2 - AGND
MUX_AIN3 = 0x7000   # A3 - AGND

# Tam ölçek aralığı (PGA)
PGA_6_144V = 0x0000   # ±6.144V  → LSB = 187.5 µV
PGA_4_096V = 0x0200   # ±4.096V  → LSB = 125.0 µV
PGA_2_048V = 0x0400   # ±2.048V  → LSB =  62.5 µV  (varsayılan)
PGA_1_024V = 0x0600   # ±1.024V  → LSB =  31.25 µV
PGA_0_512V = 0x0800   # ±0.512V  → LSB =  15.625 µV
PGA_0_256V = 0x0A00   # ±0.256V  → LSB =   7.8125 µV

# PGA'ya karşılık gelen LSB değerleri (µV)
PGA_LSB_uV = {
    PGA_6_144V: 187.5,
    PGA_4_096V: 125.0,
    PGA_2_048V: 62.5,
    PGA_1_024V: 31.25,
    PGA_0_512V: 15.625,
    PGA_0_256V: 7.8125,
}

# Örnekleme hızı (data rate)
DR_8SPS   = 0x0000
DR_16SPS  = 0x0020
DR_32SPS  = 0x0040
DR_64SPS  = 0x0060
DR_128SPS = 0x0080   # Varsayılan
DR_250SPS = 0x00A0
DR_475SPS = 0x00C0
DR_860SPS = 0x00E0

# Mod
MODE_CONTINUOUS  = 0x0000
MODE_SINGLE_SHOT = 0x0100

OS_START = 0x8000    # Tek dönüşüm başlat


class ADS1115:
    """
    ADS1115 tek/fark uçlu 16-bit ADC sürücüsü.

    Kullanım:
        from machine import I2C, Pin
        i2c = I2C(0, sda=Pin(4), scl=Pin(5), freq=400_000)
        adc = ADS1115(i2c)
        volt = adc.read_voltage(channel=0)   # A0 - AGND voltajı (ham)
    """

    def __init__(self, i2c, addr=ADS1115_ADDR_GND,
                 pga=PGA_4_096V, data_rate=DR_475SPS):
        self.i2c       = i2c
        self.addr      = addr

        # Otomatik I2C adres tespiti: 0x48 bulunamazsa diğer adresleri tara
        try:
            devices = self.i2c.scan()
            if self.addr not in devices:
                for a in [0x48, 0x49, 0x4A, 0x4B]:
                    if a in devices:
                        print(f"[ADS1115] Otomatik adres bulundu: {hex(a)}")
                        self.addr = a
                        break
                else:
                    print(f"[ADS1115 UYARI] Modul bulunamadi! Bagli I2C cihazlar: {[hex(d) for d in devices]}")
            else:
                print(f"[ADS1115] Modul basariyla baglandi: {hex(self.addr)}")
        except Exception as e:
            print("[ADS1115] I2C tarama hatasi:", e)

        self.pga       = pga
        self.data_rate = data_rate
        self._lsb_uv   = PGA_LSB_uV[pga]   # µV cinsinden LSB
        self._buf      = bytearray(2)
        self._last_err_printed = False

    # ──────────────────────────────────────────────────
    # Düşük seviye I2C okuma / yazma (Repeated START uyumlu)
    # ──────────────────────────────────────────────────
    def _write_register(self, reg, value):
        self._buf[0] = (value >> 8) & 0xFF
        self._buf[1] = value & 0xFF
        self.i2c.writeto_mem(self.addr, reg, self._buf)

    def _read_register(self, reg):
        data = self.i2c.readfrom_mem(self.addr, reg, 2)
        return (data[0] << 8) | data[1]

    # ──────────────────────────────────────────────────
    # Tek dönüşüm (single-shot) okuma
    # ──────────────────────────────────────────────────
    def _mux_for_channel(self, channel):
        return [MUX_AIN0, MUX_AIN1, MUX_AIN2, MUX_AIN3][channel & 3]

    def read_raw(self, channel=0, samples=1):
        """
        Belirtilen kanaldaki ham 16-bit işaretli tam sayıyı döner.
        Kanal (MUX) değişimlerinde hatasız ve tam dönüşüm bekler.
        """
        mux = self._mux_for_channel(channel)
        config = (OS_START |
                  mux        |
                  self.pga   |
                  MODE_SINGLE_SHOT |
                  self.data_rate   |
                  0x0003)

        total = 0
        valid_samples = 0
        # 475 SPS donusum suresi ~2.1ms'dir. 2.5ms (2500us) donusumun tamamlanmasini garanti eder.
        wait_us = 2500 if self.data_rate == DR_475SPS else 8500

        for _ in range(samples):
            try:
                self._write_register(REG_CONFIG, config)
                time.sleep_us(wait_us)
                raw = self._read_register(REG_CONVERT)
                if raw > 32767:
                    raw -= 65536
                total += raw
                valid_samples += 1
                self._last_err_printed = False
            except Exception as e:
                if not self._last_err_printed:
                    print(f"[ADS1115 Hata] Kanal A{channel} okunamadi:", e)
                    self._last_err_printed = True

        if valid_samples == 0:
            return 0
        return total // valid_samples



    def read_voltage(self, channel=0, samples=1):
        """
        Volt cinsinden ADC ölçümü döner (PGA konfigürasyonuna göre).
        Negatif değer: girişin AGND'den küçük olduğu durumlar.
        """
        raw = self.read_raw(channel, samples)
        return raw * self._lsb_uv / 1_000_000   # µV → V


# ─── Gerilim Bölücü ile DC Gerilim Ölçümü ────────────────────────────────────
class DCVoltMeter:
    """
    100kΩ / 10kΩ gerilim bölücü + ADS1115 A0 ile 0–30V DC ölçüm modülü.

    Bölücü oranı: (100k + 10k) / 10k = 11.0
    ADS1115 PGA=±4.096V olarak ayarlanmalı.

    Kullanım:
        vm = DCVoltMeter(adc, ratio=11.0, offset=0.0)
        volt = vm.measure()   # 0.0 – 30.0 V
    """

    CHANNEL = 0   # ADS1115 A0 girişi

    def __init__(self, adc: ADS1115, ratio=11.0, offset=0.0, samples=2):
        self.adc     = adc
        self.ratio   = ratio    # Gerilim bölücü oranı
        self.offset  = offset   # Kalibrasyon kayması (V)
        self.samples = samples
        self._last_v = 0.0

    def measure(self):
        """Hızlı ve kararlı DC gerilim ölçümü (0–30V)."""
        v_in = self.adc.read_voltage(self.CHANNEL, self.samples)

        # AUTO-ZERO: Boşta parazit okumayı sıfırla (< 3mV)
        if abs(v_in) < 0.003:
            self._last_v = 0.00
            return 0.00

        result = v_in * self.ratio + self.offset
        return max(0.0, result)




# ─── ACS712 ile Akım Ölçümü ────────────────────────────────────────────────
class CurrentMeter:
    """
    ACS712 (5A modeli varsayılan) + ADS1115 A1 ile DC akım ölçümü.

    ACS712-5A:
      - Hassasiyet: 185 mV/A
      - Referans (sıfır akım): VCC/2 ≈ 2.5V → ADS1115 girişine Zener ile 3.3V klip

    ACS712-20A:
      - Hassasiyet: 100 mV/A

    Kullanım:
        cm = CurrentMeter(adc, sensitivity_mv=185, zero_v=2.5)
        amps = cm.measure()
    """

    CHANNEL = 1   # ADS1115 A1 girişi

    def __init__(self, adc: ADS1115,
                 sensitivity_mv=185.0,
                 zero_v=2.5,
                 samples=16):
        self.adc            = adc
        self.sensitivity    = sensitivity_mv / 1000.0   # mV → V/A
        self.zero_v         = zero_v    # Sıfır akımdaki referans voltajı
        self.samples        = samples
        self._zero_offset   = 0.0      # Kalibrasyon sonrası sıfır kayması

    def calibrate_zero(self, n=32):
        """
        Devre açıkken (0A durumunda) sıfır offsetini öğren.
        Devreye akım bağlamadan çağırın.
        """
        v = self.adc.read_voltage(self.CHANNEL, n)
        self._zero_offset = v - self.zero_v
        return self._zero_offset

    def measure(self):
        """Akımı Amper cinsinden döner. Negatif = ters akım."""
        v = self.adc.read_voltage(self.CHANNEL, self.samples)
        amps = (v - self.zero_v - self._zero_offset) / self.sensitivity
        return amps

    def measure_abs(self):
        """Mutlak değer olarak akım (yönden bağımsız)."""
        return abs(self.measure())


# ─── Diyot / Kısa Devre / Direnç Tester ──────────────────────────────────────
class DiodeTester:
    """
    ADS1115 A2 + 1kΩ pull-up direnci ile diyot, direnç ve kısa devre testi.
    """
    CHANNEL      = 2
    V_OPEN_MIN   = 3.2    # Bu değerin üzeri = açık devre
    # Standart multimetrelerde 30-50 Ohm altı "Kısa Devre / Süreklilik Var" kabul edilir.
    # 1k pull-up ile 40 Ohm ~ 0.125V gerilime denk gelir.
    V_SHORT_MAX  = 0.13   # ~40 Ohm altı = KISA DEVRE / TEMAS VAR (Buzzer öter)
    R_PULLUP     = 1000.0 # 1k Ohm pull-up direncimiz
    V_REF        = 3.3    # Referans voltaj

    def __init__(self, adc: ADS1115, samples=2):
        self.adc     = adc
        self.samples = samples

    def measure(self):
        vf = self.adc.read_voltage(self.CHANNEL, self.samples)

        if vf >= self.V_OPEN_MIN:
            return {'type': 'OPEN', 'vf': vf, 'ohms': float('inf')}
        else:
            # Direnç Formülü: Rx = (Vout * R_pullup) / (Vin - Vout)
            denom = max(0.001, self.V_REF - vf)
            ohms = (vf * self.R_PULLUP) / denom

            if vf <= self.V_SHORT_MAX or ohms < 40.0:
                return {'type': 'SHORT', 'vf': vf, 'ohms': max(0.0, ohms)}

            
            # Diyot mu Direnç mi ayrımı (Diyotlar genelde 0.15V - 1.0V arası düşüş yapar)
            if 0.15 <= vf <= 1.0:
                rtype = 'DIODE_OR_RES'
            else:
                rtype = 'RESISTOR'
                
            return {'type': rtype, 'vf': vf, 'ohms': ohms}
