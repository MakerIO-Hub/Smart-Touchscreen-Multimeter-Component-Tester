"""
main.py – PicoMeter Touch Ana Program
=========================================
Donanım:
  SPI1  : ILI9341 LCD + XPT2046 Dokunmatik
  I2C0  : ADS1115 16-bit ADC
  GPIO  : RGB LED + Pasif Buzzer
"""

import machine
import time

from ili9341  import ILI9341
from xpt2046  import XPT2046
from ads1115  import ADS1115, DCVoltMeter, CurrentMeter, DiodeTester, PGA_4_096V
from notifier import Notifier, MODE_VOLT, MODE_DIODE, MODE_CURRENT
from ui       import MultiMeterUI

# ════════════════════════════════════════════════════════════════════════════
# 1. DONANIM BAŞLATMA
# ════════════════════════════════════════════════════════════════════════════
spi = machine.SPI(
    1,
    baudrate=40_000_000,
    polarity=0,
    phase=0,
    sck =machine.Pin(10),
    mosi=machine.Pin(11),
    miso=machine.Pin(12),
)

lcd_cs  = machine.Pin(8,  machine.Pin.OUT, value=1)
lcd_dc  = machine.Pin(9,  machine.Pin.OUT, value=0)
lcd_rst = machine.Pin(13, machine.Pin.OUT, value=1)
lcd_led = machine.Pin(14, machine.Pin.OUT, value=1)
t_cs    = machine.Pin(15, machine.Pin.OUT, value=1)

i2c = machine.I2C(0, sda=machine.Pin(16), scl=machine.Pin(17), freq=100_000)

display  = ILI9341(spi, lcd_cs, lcd_dc, lcd_rst, lcd_led)
touch    = XPT2046(spi, t_cs,  width=320, height=240)
adc      = ADS1115(i2c, pga=PGA_4_096V)
notify   = Notifier(pin_red=2, pin_green=3, pin_blue=1, pin_buzzer=22)
ui       = MultiMeterUI(display)

vm = DCVoltMeter (adc, ratio=11.0, samples=2)
cm = CurrentMeter(adc, sensitivity_mv=185.0, zero_v=2.5, samples=4)
dm = DiodeTester (adc, samples=2)

# ════════════════════════════════════════════════════════════════════════════
# 2. AÇILIŞ SEKANSΙ
# ════════════════════════════════════════════════════════════════════════════
notify.startup_sequence()
ui.show_splash()
time.sleep_ms(1500)

ui.d.draw_text_center(180, 'Calibrating Sensors...', 0x07E0, 0x18E3, size=1)
cm.calibrate_zero(n=32)

# ─── Durum Değişkenleri ──────────────────────────────────────────────────────
# current_view: 'MAIN' | 'COMP_MENU' | 'HW_WARNING'
current_view = 'MAIN'
menu_page = 1
selected_comp_idx = 0      # Varsayılan 0: Resistance
selected_comp_name = "1.Resistance"

current_mode = 'VOLT'      # 'VOLT', 'DIODE' (Component Ölçüm), 'CURRENT'
is_hold_active = False
min_v = 99.0
max_v = 0.0

ui.draw_base(current_mode)
notify.set_mode(MODE_VOLT)

# ────────────────────────────────────────────────────────────────────────────
# 3. YARDIMCI FONKSİYONLAR
# ────────────────────────────────────────────────────────────────────────────
def read_touch_coord():
    """Dokunmatik koordinatlarını güvenli bir şekilde oku."""
    spi.init(baudrate=2_000_000, polarity=0, phase=0)
    pt = touch.get_touch()
    spi.init(baudrate=40_000_000, polarity=0, phase=0)
    return pt

def switch_main_mode(new_mode):
    global current_mode, min_v, max_v, is_hold_active, current_view
    current_mode = new_mode
    current_view = 'MAIN'
    min_v = 99.0
    max_v = 0.0
    is_hold_active = False
    
    sub_title = selected_comp_name if new_mode == 'DIODE' else None
    # Continuity (selected_comp_idx == 4) modunda HOLD kapalıdır
    allow_hold = not (new_mode == 'DIODE' and selected_comp_idx == 4)
    
    ui.draw_base(new_mode, submode_title=sub_title, allow_hold=allow_hold)
    notify.stop_alarm()
    
    mode_map = {'VOLT': MODE_VOLT, 'DIODE': MODE_DIODE, 'CURRENT': MODE_CURRENT}
    notify.set_mode(mode_map[new_mode])
    notify.beep_ok()

def toggle_hold():
    global is_hold_active
    # Continuity modunda HOLD engellenir
    if current_mode == 'DIODE' and selected_comp_idx == 4:
        return
        
    is_hold_active = not is_hold_active
    ui.update_hold_status(is_hold_active)
    notify.beep(440 if is_hold_active else 330, 80)


# ─── Ekran Koruyucu (Screensaver) Durumu ──────────────────────────────────
SCREENSAVER_TIMEOUT_MS = 60_000   # 1 dakika (60 sn) işlem yapılmazsa uyu
last_activity_time = time.ticks_ms()
screensaver_anim_tick = 0
eye_directions = ['CENTER', 'RIGHT', 'CENTER', 'LEFT', 'UP', 'CENTER']
eye_dir_idx = 0


# ════════════════════════════════════════════════════════════════════════════
# 4. ANA DÖNGÜ
# ════════════════════════════════════════════════════════════════════════════
_SHORT_ALARM_ACTIVE = False
_LOOP_TICK = 0

print("PicoMeter Touch + Component Menu + Screensaver baslatildi.")

while True:
    _LOOP_TICK += 1
    pt = read_touch_coord()
    now = time.ticks_ms()

    # Dokunma olursa son etkinlik zamanını güncelle
    if pt:
        last_activity_time = now

    # ─────────────────────────────────────────────────────────────────────────
    # EKRAN KORUYUCU (SCREENSAVER) KONTROLÜ
    # ─────────────────────────────────────────────────────────────────────────
    if current_view != 'SCREENSAVER':
        if time.ticks_diff(now, last_activity_time) > SCREENSAVER_TIMEOUT_MS:
            # 30 saniye boyunca dokunulmadı -> Screensaver'a geç
            current_view = 'SCREENSAVER'
            ui.draw_screensaver_base()
            ui.draw_screensaver_eyes('CENTER', blink=False)
            notify.stop_alarm()
            print("[SCREENSAVER] 30 sn hareketsizlik -> Gozler acildi.")
            time.sleep_ms(200)
            continue
    else:
        # Ekran koruyucu aktifken herhangi bir dokunuş gelirse:
        if pt:
            notify.beep_ok()
            print("[SCREENSAVER] Dokunus algilandi -> DC VOLT Ana Sayfasina donuluyor.")
            last_activity_time = now
            switch_main_mode('VOLT')  # Doğrudan Ana Sayfa (DC Volt) moduna dön
            time.sleep_ms(300)
            continue

        # Ekran koruyucuda sevimli göz animasyonları oynat (~her 1.5 saniyede bir bakış değiştir/göz kırp)
        screensaver_anim_tick += 1
        if screensaver_anim_tick % 40 == 0:
            # Göz kırpma
            ui.draw_screensaver_eyes(eye_directions[eye_dir_idx], blink=True)
            time.sleep_ms(150)
            eye_dir_idx = (eye_dir_idx + 1) % len(eye_directions)
            ui.draw_screensaver_eyes(eye_directions[eye_dir_idx], blink=False)

        time.sleep_ms(50)
        continue

    # ─────────────────────────────────────────────────────────────────────────
    # GÖRÜNÜM 1: ALT MENÜ (COMPONENT SEÇİM EKRANI)
    # ─────────────────────────────────────────────────────────────────────────
    if current_view == 'COMP_MENU':
        if pt:
            tx, ty = pt
            action = ui.detect_component_menu_touch(tx, ty, menu_page)
            print(f"[MENU TOUCH] X:{tx}, Y:{ty} --> {action}")

            
            if action == 'BACK':
                notify.beep_ok()
                switch_main_mode('DIODE')
                time.sleep_ms(250)
                continue
                
            elif action == 'NEXT_PAGE':
                menu_page = 2
                ui.draw_component_menu(menu_page)
                notify.beep(600, 40)
                time.sleep_ms(250)
                continue
                
            elif action == 'PREV_PAGE':
                menu_page = 1
                ui.draw_component_menu(menu_page)
                notify.beep(600, 40)
                time.sleep_ms(250)
                continue
                
            elif action and action.startswith('COMP_'):
                idx = int(action.split('_')[1])
                comp_info = ui.COMPONENTS[idx]
                comp_name, is_supported, req_note = comp_info
                selected_comp_idx = idx
                selected_comp_name = comp_name

                if is_supported:
                    notify.beep_ok()
                    print(f"Secilen Fonksiyon: {comp_name} (Hazır)")
                    switch_main_mode('DIODE')
                else:
                    notify.beep_error()
                    print(f"Secilen Fonksiyon: {comp_name} (Donanım Yok)")
                    current_view = 'HW_WARNING'
                    ui.show_hw_warning(comp_name, req_note)
                time.sleep_ms(300)
                continue

        time.sleep_ms(60)
        continue

    # ─────────────────────────────────────────────────────────────────────────
    # GÖRÜNÜM 2: DONANIM EKSİK UYARISI
    # ─────────────────────────────────────────────────────────────────────────
    elif current_view == 'HW_WARNING':
        if pt:
            tx, ty = pt
            action = ui.detect_hw_warning_touch(tx, ty)
            if action == 'BACK':
                notify.beep_ok()
                current_view = 'COMP_MENU'
                ui.draw_component_menu(menu_page)
                time.sleep_ms(250)
        time.sleep_ms(60)
        continue

    # ─────────────────────────────────────────────────────────────────────────
    # GÖRÜNÜM 3: ANA ÖLÇÜM EKRANI
    # ─────────────────────────────────────────────────────────────────────────
    else:
        if pt:
            tx, ty = pt
            action = ui.detect_touch_zone(tx, ty)
            
            if action == 'HOLD':
                toggle_hold()
                time.sleep_ms(250)
                continue
            elif action == 'VOLT':
                switch_main_mode('VOLT')
                time.sleep_ms(250)
                continue
            elif action == 'CURRENT':
                switch_main_mode('CURRENT')
                time.sleep_ms(250)
                continue
            elif action == 'DIODE':
                # COMPONENT butonuna basıldığında ALT MENÜ'yü aç
                notify.beep_ok()
                current_view = 'COMP_MENU'
                ui.draw_component_menu(menu_page)
                time.sleep_ms(250)
                continue

        # ── Mod: DC VOLTMETRE ────────────────────────────────────────────────
        if current_mode == 'VOLT':
            volt = vm.measure()
            min_v = min(min_v, volt)
            max_v = max(max_v, volt)

            if not is_hold_active:
                ui.show_volt(volt, min_v, max_v)

            if volt > 29.5 and not is_hold_active:
                notify.beep_error()

        # ── Mod: COMPONENT TESTLERİ ──────────────────────────────────────────
        elif current_mode == 'DIODE':
            # 10. Pil / Batarya Testi Seçilmişse A0 kanalından ölç
            if selected_comp_idx == 9: # 10.Battery Test
                volt = vm.measure()
                min_v = min(min_v, volt)
                max_v = max(max_v, volt)
                if not is_hold_active:
                    ui.show_volt(volt, min_v, max_v)
            else:
                result = dm.measure()
                rtype  = result['type']
                vf     = result['vf']
                ohms   = result['ohms']

                # Alt Fonksiyonlara Özel Görünüm
                if not is_hold_active:
                    if selected_comp_idx == 0:    # 1. Resistance
                        ui.show_resistance_only(ohms, vf)
                    elif selected_comp_idx == 2:  # 3. Diode Test
                        ui.show_diode(rtype, vf, ohms)
                    elif selected_comp_idx == 3:  # 4. LED Test
                        ui.show_led_test(rtype, vf)
                    elif selected_comp_idx == 4:  # 5. Continuity
                        is_short = (rtype == 'SHORT')
                        ui.show_continuity(is_short, vf, ohms)
                    else:
                        ui.show_diode(rtype, vf, ohms)

                # Süreklilik / Kısa devre buzzer kontrolü
                if rtype == 'SHORT':
                    if not _SHORT_ALARM_ACTIVE:
                        _SHORT_ALARM_ACTIVE = True
                        notify.short_circuit_alarm()
                else:
                    if _SHORT_ALARM_ACTIVE:
                        _SHORT_ALARM_ACTIVE = False
                        notify.stop_alarm()


        # ── Mod: AKIM & GÜÇ ──────────────────────────────────────────────────
        elif current_mode == 'CURRENT':
            amps = cm.measure()
            volt = vm.measure()
            
            if not is_hold_active:
                ui.show_current(amps, volt)

            if abs(amps) > 4.8 and not is_hold_active:
                notify.beep_error()

    time.sleep_ms(20) # Hızlı ve akıcı yenileme (~25Hz)