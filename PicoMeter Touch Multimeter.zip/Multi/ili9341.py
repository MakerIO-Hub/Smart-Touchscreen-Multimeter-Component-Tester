"""
ili9341.py – ILI9341 2.4" SPI Ekran Sürücüsü
Pico 2 GPIO Pin Haritası (SPI1):
  SCK  → GP10  (Pin 14)
  MOSI → GP11  (Pin 15)
  MISO → GP12  (Pin 16)
  CS   → GP8   (Pin 11)
  DC   → GP9   (Pin 12)
  RST  → GP13  (Pin 17)
  LED  → GP14  (Pin 19)

Ekran Modu: Landscape 320 × 240 (MADCTL = 0xE8)
"""

import struct
import time


# ─── RGB565 Renk Sabitleri ───────────────────────────────────────────────────
BLACK   = 0x0000
WHITE   = 0xFFFF
RED     = 0xF800
GREEN   = 0x07E0
BLUE    = 0x001F
CYAN    = 0x07FF
MAGENTA = 0xF81F
YELLOW  = 0xFFE0
ORANGE  = 0xFC00
GRAY    = 0x39E7
DARKGRAY= 0x2104
NAVY    = 0x000F
DARKGREEN=0x03E0


def color565(r, g, b):
    """RGB888 → RGB565 dönüşümü"""
    return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3)


class ILI9341:
    """
    ILI9341 tam özellikli sürücü.
    Landscape modunda kullanılır: genişlik=320, yükseklik=240.
    """

    WIDTH  = 320   # Landscape genişlik
    HEIGHT = 240   # Landscape yükseklik

    # 5×8 bit-map karakter seti (5 sütun, 8 satır)
    # Her eleman: 5 byte, her byte bir sütun (LSB = üst satır)
    FONT5x8 = {
        ' ' : [0x00, 0x00, 0x00, 0x00, 0x00],
        '!' : [0x00, 0x00, 0x5F, 0x00, 0x00],
        '"' : [0x00, 0x07, 0x00, 0x07, 0x00],
        '#' : [0x14, 0x7F, 0x14, 0x7F, 0x14],
        '%' : [0x23, 0x13, 0x08, 0x64, 0x62],
        '+' : [0x08, 0x08, 0x3E, 0x08, 0x08],
        '-' : [0x08, 0x08, 0x08, 0x08, 0x08],
        '.' : [0x00, 0x60, 0x60, 0x00, 0x00],
        '/' : [0x20, 0x10, 0x08, 0x04, 0x02],
        ':' : [0x00, 0x36, 0x36, 0x00, 0x00],
        '<' : [0x08, 0x14, 0x22, 0x41, 0x00],
        '>' : [0x00, 0x41, 0x22, 0x14, 0x08],
        'A' : [0x7E, 0x11, 0x11, 0x11, 0x7E],
        'B' : [0x7F, 0x49, 0x49, 0x49, 0x36],
        'C' : [0x3E, 0x41, 0x41, 0x41, 0x22],
        'D' : [0x7F, 0x41, 0x41, 0x22, 0x1C],
        'E' : [0x7F, 0x49, 0x49, 0x49, 0x41],
        'F' : [0x7F, 0x09, 0x09, 0x09, 0x01],
        'G' : [0x3E, 0x41, 0x49, 0x49, 0x7A],
        'H' : [0x7F, 0x08, 0x08, 0x08, 0x7F],
        'I' : [0x00, 0x41, 0x7F, 0x41, 0x00],
        'J' : [0x20, 0x40, 0x41, 0x3F, 0x01],
        'K' : [0x7F, 0x08, 0x14, 0x22, 0x41],
        'L' : [0x7F, 0x40, 0x40, 0x40, 0x40],
        'M' : [0x7F, 0x02, 0x04, 0x02, 0x7F],
        'N' : [0x7F, 0x04, 0x08, 0x10, 0x7F],
        'O' : [0x3E, 0x41, 0x41, 0x41, 0x3E],
        'P' : [0x7F, 0x09, 0x09, 0x09, 0x06],
        'Q' : [0x3E, 0x41, 0x51, 0x21, 0x5E],
        'R' : [0x7F, 0x09, 0x19, 0x29, 0x46],
        'S' : [0x46, 0x49, 0x49, 0x49, 0x31],
        'T' : [0x01, 0x01, 0x7F, 0x01, 0x01],
        'U' : [0x3F, 0x40, 0x40, 0x40, 0x3F],
        'V' : [0x1F, 0x20, 0x40, 0x20, 0x1F],
        'W' : [0x7F, 0x20, 0x18, 0x20, 0x7F],
        'X' : [0x63, 0x14, 0x08, 0x14, 0x63],
        'Y' : [0x07, 0x08, 0x70, 0x08, 0x07],
        'Z' : [0x61, 0x51, 0x49, 0x45, 0x43],
        '0' : [0x3E, 0x51, 0x49, 0x45, 0x3E],
        '1' : [0x00, 0x42, 0x7F, 0x40, 0x00],
        '2' : [0x42, 0x61, 0x51, 0x49, 0x46],
        '3' : [0x21, 0x41, 0x45, 0x4B, 0x31],
        '4' : [0x18, 0x14, 0x12, 0x7F, 0x10],
        '5' : [0x27, 0x45, 0x45, 0x45, 0x39],
        '6' : [0x3C, 0x4A, 0x49, 0x49, 0x30],
        '7' : [0x01, 0x71, 0x09, 0x05, 0x03],
        '8' : [0x36, 0x49, 0x49, 0x49, 0x36],
        '9' : [0x06, 0x49, 0x49, 0x29, 0x1E],
        'a' : [0x20, 0x54, 0x54, 0x54, 0x78],
        'b' : [0x7F, 0x48, 0x44, 0x44, 0x38],
        'c' : [0x38, 0x44, 0x44, 0x44, 0x20],
        'd' : [0x38, 0x44, 0x44, 0x48, 0x7F],
        'e' : [0x38, 0x54, 0x54, 0x54, 0x18],
        'f' : [0x08, 0x7E, 0x09, 0x01, 0x02],
        'g' : [0x0C, 0x52, 0x52, 0x52, 0x3E],
        'h' : [0x7F, 0x08, 0x04, 0x04, 0x78],
        'i' : [0x00, 0x44, 0x7D, 0x40, 0x00],
        'j' : [0x20, 0x40, 0x44, 0x3D, 0x00],
        'k' : [0x7F, 0x10, 0x28, 0x44, 0x00],
        'l' : [0x00, 0x41, 0x7F, 0x40, 0x00],
        'm' : [0x78, 0x04, 0x18, 0x04, 0x78],
        'n' : [0x7C, 0x08, 0x04, 0x04, 0x78],
        'o' : [0x38, 0x44, 0x44, 0x44, 0x38],
        'p' : [0x7C, 0x14, 0x14, 0x14, 0x08],
        'q' : [0x08, 0x14, 0x14, 0x18, 0x7C],
        'r' : [0x7C, 0x08, 0x04, 0x04, 0x08],
        's' : [0x48, 0x54, 0x54, 0x54, 0x20],
        't' : [0x04, 0x3F, 0x44, 0x40, 0x20],
        'u' : [0x3C, 0x40, 0x40, 0x20, 0x7C],
        'v' : [0x1C, 0x20, 0x40, 0x20, 0x1C],
        'w' : [0x3C, 0x40, 0x30, 0x40, 0x3C],
        'x' : [0x44, 0x28, 0x10, 0x28, 0x44],
        'y' : [0x0C, 0x50, 0x50, 0x50, 0x3C],
        'z' : [0x44, 0x64, 0x54, 0x4C, 0x44],
    }

    def __init__(self, spi, cs, dc, rst, led=None):
        self.spi = spi
        self.cs  = cs
        self.dc  = dc
        self.rst = rst
        self.led = led
        self._buf2 = bytearray(2)
        self.reset()
        self._init_sequence()
        if led:
            led.value(1)

    # ──────────────────────────────────────────────────
    # Temel SPI yazma metodları
    # ──────────────────────────────────────────────────
    def _write_cmd(self, cmd):
        self.dc.value(0)
        self.cs.value(0)
        self.spi.write(bytearray([cmd]))
        self.cs.value(1)

    def _write_data(self, data):
        self.dc.value(1)
        self.cs.value(0)
        self.spi.write(data)
        self.cs.value(1)

    def _write_data16(self, val):
        """Tek bir 16-bit renk değerini yaz (struct overhead olmadan)"""
        self._buf2[0] = val >> 8
        self._buf2[1] = val & 0xFF
        self.dc.value(1)
        self.cs.value(0)
        self.spi.write(self._buf2)
        self.cs.value(1)

    # ──────────────────────────────────────────────────
    # Donanım sıfırlama ve başlatma dizisi
    # ──────────────────────────────────────────────────
    def reset(self):
        self.rst.value(1)
        time.sleep_ms(5)
        self.rst.value(0)
        time.sleep_ms(20)
        self.rst.value(1)
        time.sleep_ms(150)

    def _init_sequence(self):
        init = [
            (0xEF, b'\x03\x80\x02'),
            (0xCF, b'\x00\xC1\x30'),
            (0xED, b'\x64\x03\x12\x81'),
            (0xE8, b'\x85\x00\x78'),
            (0xCB, b'\x39\x2C\x00\x34\x02'),
            (0xF7, b'\x20'),
            (0xEA, b'\x00\x00'),
            (0xC0, b'\x23'),           # Power Control 1
            (0xC1, b'\x10'),           # Power Control 2
            (0xC5, b'\x3E\x28'),       # VCOM Control 1
            (0xC7, b'\x86'),           # VCOM Control 2
            # MADCTL = 0xE8 → Landscape, BGR renk sırası
            (0x36, b'\xE8'),
            (0x3A, b'\x55'),           # Pixel Format: 16-bit RGB565
            (0xB1, b'\x00\x18'),       # Frame Rate
            (0xB6, b'\x08\x82\x27'),   # Display Function Control
            (0xF2, b'\x00'),           # 3-Gamma off
            (0x26, b'\x01'),           # Gamma Set
            (0xE0, b'\x0F\x31\x2B\x0C\x0E\x08\x4E\xF1\x37\x07\x10\x03\x0E\x09\x00'),
            (0xE1, b'\x00\x0E\x14\x03\x11\x07\x31\xC1\x48\x08\x0F\x0C\x31\x36\x0F'),
        ]
        for cmd, data in init:
            self._write_cmd(cmd)
            if data:
                self._write_data(data)
        self._write_cmd(0x11)  # Sleep Out
        time.sleep_ms(120)
        self._write_cmd(0x29)  # Display ON

    # ──────────────────────────────────────────────────
    # Pencere (adres) ayarı
    # ──────────────────────────────────────────────────
    def set_window(self, x0, y0, x1, y1):
        self._write_cmd(0x2A)
        self._write_data(struct.pack('>HH', x0, x1))
        self._write_cmd(0x2B)
        self._write_data(struct.pack('>HH', y0, y1))
        self._write_cmd(0x2C)

    # ──────────────────────────────────────────────────
    # Temel çizim metodları
    # ──────────────────────────────────────────────────
    def fill_screen(self, color):
        self.fill_rect(0, 0, self.WIDTH, self.HEIGHT, color)

    def fill_rect(self, x, y, w, h, color):
        if w <= 0 or h <= 0:
            return
        x1 = min(x + w - 1, self.WIDTH - 1)
        y1 = min(y + h - 1, self.HEIGHT - 1)
        x  = max(0, x)
        y  = max(0, y)
        if x1 < x or y1 < y:
            return
        self.set_window(x, y, x1, y1)
        count  = (x1 - x + 1) * (y1 - y + 1)
        chunk  = struct.pack('>H', color) * min(count, 256)
        self.dc.value(1)
        self.cs.value(0)
        full, rem = divmod(count, 256)
        for _ in range(full):
            self.spi.write(chunk)
        if rem:
            self.spi.write(struct.pack('>H', color) * rem)
        self.cs.value(1)

    def draw_pixel(self, x, y, color):
        if 0 <= x < self.WIDTH and 0 <= y < self.HEIGHT:
            self.set_window(x, y, x, y)
            self._write_data16(color)

    def draw_hline(self, x, y, length, color):
        self.fill_rect(x, y, length, 1, color)

    def draw_vline(self, x, y, length, color):
        self.fill_rect(x, y, 1, length, color)

    def draw_rect(self, x, y, w, h, color):
        self.draw_hline(x, y, w, color)
        self.draw_hline(x, y + h - 1, w, color)
        self.draw_vline(x, y, h, color)
        self.draw_vline(x + w - 1, y, h, color)

    def draw_line(self, x0, y0, x1, y1, color):
        """Bresenham çizgi algoritması"""
        dx = abs(x1 - x0)
        dy = abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx - dy
        while True:
            self.draw_pixel(x0, y0, color)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x0  += sx
            if e2 < dx:
                err += dx
                y0  += sy

    def draw_circle(self, cx, cy, r, color):
        """Midpoint çember algoritması"""
        x, y, err = r, 0, 0
        while x >= y:
            self.draw_pixel(cx + x, cy + y, color)
            self.draw_pixel(cx - x, cy + y, color)
            self.draw_pixel(cx + x, cy - y, color)
            self.draw_pixel(cx - x, cy - y, color)
            self.draw_pixel(cx + y, cy + x, color)
            self.draw_pixel(cx - y, cy + x, color)
            self.draw_pixel(cx + y, cy - x, color)
            self.draw_pixel(cx - y, cy - x, color)
            y   += 1
            err += 1 + 2 * y
            if 2 * (err - x) + 1 > 0:
                x   -= 1
                err += 1 - 2 * x

    def fill_circle(self, cx, cy, r, color):
        for dy in range(-r, r + 1):
            dx = int((r * r - dy * dy) ** 0.5)
            self.draw_hline(cx - dx, cy + dy, 2 * dx + 1, color)

    # ──────────────────────────────────────────────────
    # Karakter ve metin çizimi
    # ──────────────────────────────────────────────────
    def draw_char(self, x, y, ch, color, bg, size=2):
        """Tek karakter çiz. size=1 → 5×8 px, size=2 → 10×16 px"""
        glyph = self.FONT5x8.get(ch, self.FONT5x8.get(ch.upper(), self.FONT5x8[' ']))
        for col, bits in enumerate(glyph):
            for row in range(8):
                c = color if (bits >> row) & 1 else bg
                if size == 1:
                    self.draw_pixel(x + col, y + row, c)
                else:
                    self.fill_rect(x + col * size, y + row * size, size, size, c)
        # Karakter sonrası boşluk
        self.fill_rect(x + 5 * size, y, size, 8 * size, bg)

    def draw_text(self, x, y, text, color, bg=BLACK, size=2):
        """Metin çiz. Döner: son karakter sonrasındaki x koordinatı."""
        cx = x
        for ch in str(text):
            self.draw_char(cx, y, ch, color, bg, size)
            cx += 6 * size
        return cx

    def text_width(self, text, size=2):
        return len(text) * 6 * size

    def text_height(self, size=2):
        return 8 * size

    def draw_text_center(self, y, text, color, bg=BLACK, size=2):
        """Metni yatay ortalayarak çiz."""
        tw = self.text_width(text, size)
        x  = max(0, (self.WIDTH - tw) // 2)
        self.draw_text(x, y, text, color, bg, size)

    # ──────────────────────────────────────────────────
    # Yüksek seviyeli UI bileşenleri
    # ──────────────────────────────────────────────────
    def draw_button(self, x, y, w, h, label, bg_color, text_color=WHITE, size=2, border=True):
        """Renkli dikdörtgen buton çizer."""
        self.fill_rect(x, y, w, h, bg_color)
        if border:
            self.draw_rect(x, y, w, h, WHITE)
        tw = self.text_width(label, size)
        th = self.text_height(size)
        tx = x + (w - tw) // 2
        ty = y + (h - th) // 2
        self.draw_text(tx, ty, label, text_color, bg_color, size)

    def draw_bar(self, x, y, w, h, value, max_val, fill_color, bg_color=DARKGRAY):
        """Yatay dolgu çubuğu (progress bar)."""
        self.fill_rect(x, y, w, h, bg_color)
        fill_w = int(value / max_val * w) if max_val else 0
        fill_w = max(0, min(w, fill_w))
        if fill_w:
            self.fill_rect(x, y, fill_w, h, fill_color)
