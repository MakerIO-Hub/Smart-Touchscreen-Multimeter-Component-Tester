"""
ui.py – Multimeter User Interface (PicoMeter Touch)
"""

from ili9341 import (
    ILI9341, BLACK, WHITE, RED, GREEN, BLUE,
    CYAN, YELLOW, ORANGE, GRAY, DARKGRAY, NAVY, DARKGREEN, color565
)

# ─── Color Palette ───────────────────────────────────────────────────────────
C_HEADER    = color565(30, 30, 30)
C_VOLT      = color565(255, 80, 80)
C_DIODE     = color565(100, 255, 120)
C_CURRENT   = color565(80, 180, 255)
C_BAR_BG    = color565(50, 50, 50)
C_HOLD_ON   = YELLOW
C_HOLD_OFF  = GRAY
C_BTN_VOLT  = color565(200, 40, 40)
C_BTN_DIODE = color565(40, 180, 40)
C_BTN_AMP   = color565(40, 80, 200)
C_SELECTED  = WHITE

# ─── Layout Constants ────────────────────────────────────────────────────────
TOP_H       = 30
VALUE_Y     = 45
VALUE_H     = 50
BAR_Y       = 100
BAR_H       = 15
INFO_Y1     = 125
INFO_Y2     = 150
LINE_Y      = 185
BTN_Y       = 190
BTN_H       = 45

BTN_VOLT_X0,  BTN_VOLT_X1  = 5, 105
BTN_DIODE_X0, BTN_DIODE_X1 = 110, 210
BTN_AMP_X0,   BTN_AMP_X1   = 215, 315
BTN_HOLD_X0,  BTN_HOLD_X1  = 260, 315

SCREEN_W = 320
SCREEN_H = 240

class MultiMeterUI:
    def __init__(self, display: ILI9341):
        self.d = display
        self._mode = None
        self._submode = None
        self._last_value_str = ''
        self._last_unit_str  = ''
        self._last_info_str  = ''
        self._is_hold = False
        
        # 10 Component Functions: (Title, Supported, Hardware Requirement Description)
        self.COMPONENTS = [
            ("1.Resistance", True, "Resistance Measurement (Ohm, kOhm, MOhm)"),
            ("2.Capacitance", False, "Requires Charge/Discharge GPIO and Ref Resistor"),
            ("3.Diode Test", True, "Diode Test & Forward Voltage (Vf)"),
            ("4.LED Test", True, "LED Forward Voltage (Vf) & Color Check"),
            ("5.Continuity", True, "Continuity Test & Audio Buzzer"),
            ("6.Transistor", False, "Requires BJT Test Socket & Dual Bias Lines"),
            ("7.Inductance", False, "Requires LC Resonance / Oscillator Circuit"),
            ("8.Zener Test", False, "Requires Boost Step-Up (>15V-30V) Generator"),
            ("9.MOSFET Test", False, "Requires Gate Drive & Drain-Source Load Circuit"),
            ("10.Battery Test", True, "DC Battery Voltage & Cell Analysis on A0")
        ]

    # ──────────────────────────────────────────────────
    # Base Screen Drawing
    # ──────────────────────────────────────────────────
    def draw_base(self, mode, submode_title=None, allow_hold=True):
        self._mode = mode
        self._submode = submode_title
        self.d.fill_screen(BLACK)
        self._draw_top_bar(mode, submode_title, allow_hold=allow_hold)
        self._draw_buttons(mode)
        self._draw_divider()
        self._last_value_str = ''
        self._last_info_str  = ''


    def _draw_top_bar(self, mode, submode_title=None, allow_hold=True):
        self.d.fill_rect(0, 0, SCREEN_W, TOP_H, C_HEADER)
        if submode_title:
            mode_text = submode_title[:14]
        else:
            mode_names = {'VOLT': 'MODE: DC VOLT', 'DIODE': 'MODE: COMPONENT', 'CURRENT': 'MODE: CURRENT'}
            mode_text = mode_names.get(mode, 'MODE: ???')
            
        self.d.draw_text(5, 8, mode_text, CYAN, C_HEADER, size=1)
        self.d.draw_text_center(8, "PicoMeter Touch", WHITE, C_HEADER, size=1)
        
        if allow_hold:
            self.update_hold_status(self._is_hold)
        else:
            # Continuity modunda HOLD butonu çizilmez (gizlenir)
            w = BTN_HOLD_X1 - BTN_HOLD_X0
            self.d.fill_rect(BTN_HOLD_X0, 0, w, TOP_H, C_HEADER)

    def update_hold_status(self, is_hold):
        self._is_hold = is_hold
        color = C_HOLD_ON if is_hold else GRAY
        bg_col = color565(180, 140, 0) if is_hold else color565(45, 45, 45)
        text_col = BLACK if is_hold else WHITE
        
        w = BTN_HOLD_X1 - BTN_HOLD_X0
        self.d.fill_rect(BTN_HOLD_X0, 3, w, 24, bg_col)
        self.d.draw_rect(BTN_HOLD_X0, 3, w, 24, color)
        self.d.draw_text(BTN_HOLD_X0 + 12, 8, "HOLD", text_col, bg_col, size=1)



    def _draw_divider(self):
        self.d.draw_hline(0, LINE_Y, SCREEN_W, GRAY)

    def _draw_buttons(self, mode):
        btns = [
            ('DC VOLT',   BTN_VOLT_X0,  BTN_VOLT_X1,  C_BTN_VOLT,  'VOLT'),
            ('COMPONENT', BTN_DIODE_X0, BTN_DIODE_X1, C_BTN_DIODE, 'DIODE'),
            ('CURRENT',   BTN_AMP_X0,   BTN_AMP_X1,   C_BTN_AMP,   'CURRENT'),
        ]
        for label, x0, x1, bg, m in btns:
            w = x1 - x0
            border_color = C_SELECTED if m == mode else DARKGRAY
            border_thick = 2 if m == mode else 1
            self.d.fill_rect(x0, BTN_Y, w, BTN_H, bg)
            for i in range(border_thick):
                self.d.draw_rect(x0+i, BTN_Y+i, w-(i*2), BTN_H-(i*2), border_color)
            tw = self.d.text_width(label, size=1)
            self.d.draw_text(x0 + (w - tw) // 2, BTN_Y + (BTN_H - 8) // 2, label, WHITE, bg, size=1)

    # ──────────────────────────────────────────────────
    # Submenu (Component Selection)
    # ──────────────────────────────────────────────────
    def draw_component_menu(self, page=1):
        self.d.fill_screen(BLACK)
        self.d.fill_rect(0, 0, SCREEN_W, TOP_H, C_HEADER)
        self.d.draw_text(10, 8, "SELECT COMPONENT", CYAN, C_HEADER, size=1)
        self.d.draw_text(245, 8, f"Page {page}/2", YELLOW, C_HEADER, size=1)

        start_idx = (page - 1) * 6
        for i in range(6):
            idx = start_idx + i
            if idx >= len(self.COMPONENTS):
                break
            name, supported, _ = self.COMPONENTS[idx]

            row = i // 2
            col = i % 2
            x = 8 if col == 0 else 164
            y = 38 + row * 48
            w, h = 148, 42
            bg = C_BTN_DIODE if supported else color565(55, 55, 60)
            border = WHITE if supported else GRAY

            self.d.fill_rect(x, y, w, h, bg)
            self.d.draw_rect(x, y, w, h, border)
            self.d.draw_text(x + 6, y + 10, name, WHITE, bg, size=1)
            status_text = "[READY]" if supported else "[EXTRA HW]"
            status_col  = GREEN if supported else ORANGE
            self.d.draw_text(x + 6, y + 25, status_text, status_col, bg, size=1)

        # Bottom navigation buttons
        self.d.fill_rect(0, 190, SCREEN_W, 50, C_HEADER)
        
        # Back Button (Return to Main Menu)
        self.d.fill_rect(8, 196, 110, 38, RED)
        self.d.draw_rect(8, 196, 110, 38, WHITE)
        self.d.draw_text(18, 208, "<- MAIN MENU", WHITE, RED, size=1)

        # Page Switch Button
        page_btn_text = "NEXT ->" if page == 1 else "<- PREV"
        self.d.fill_rect(202, 196, 110, 38, BLUE)
        self.d.draw_rect(202, 196, 110, 38, WHITE)
        self.d.draw_text(224, 208, page_btn_text, WHITE, BLUE, size=1)

    def show_hw_warning(self, name, req_text):
        self.d.fill_screen(BLACK)
        self.d.fill_rect(0, 0, SCREEN_W, TOP_H, RED)
        self.d.draw_text_center(8, "HARDWARE NOT READY!", WHITE, RED, size=1)
        
        self.d.draw_text_center(45, name, CYAN, BLACK, size=2)
        
        self.d.draw_rect(10, 80, 300, 95, DARKGRAY)
        self.d.fill_rect(12, 82, 296, 91, color565(20, 20, 25))
        
        self.d.draw_text(20, 90, "Required Extra Hardware:", YELLOW, color565(20, 20, 25), size=1)
        
        if len(req_text) > 36:
            mid = req_text[:36].rfind(' ')
            if mid == -1: mid = 36
            line1 = req_text[:mid]
            line2 = req_text[mid:].strip()
            self.d.draw_text(20, 115, line1, WHITE, color565(20, 20, 25), size=1)
            self.d.draw_text(20, 135, line2, WHITE, color565(20, 20, 25), size=1)
        else:
            self.d.draw_text(20, 120, req_text, WHITE, color565(20, 20, 25), size=1)
            
        self.d.draw_text_center(158, "Measurement circuit unavailable.", GRAY, color565(20, 20, 25), size=1)

        self.d.fill_rect(105, 192, 110, 38, RED)
        self.d.draw_rect(105, 192, 110, 38, WHITE)
        self.d.draw_text_center(204, "<- GO BACK", WHITE, RED, size=1)

    # ──────────────────────────────────────────────────
    # Dynamic Screen Updates
    # ──────────────────────────────────────────────────
    def update_value(self, value_str, unit_str, color):
        full = value_str + ' ' + unit_str
        if full == self._last_value_str: return
        self._last_value_str = full

        self.d.fill_rect(0, VALUE_Y, SCREEN_W, VALUE_H, BLACK)
        total_w = self.d.text_width(value_str, size=4) + 10 + self.d.text_width(unit_str, size=2)
        start_x = (SCREEN_W - total_w) // 2
        cx = self.d.draw_text(start_x, VALUE_Y + 10, value_str, color, BLACK, size=4)
        self.d.draw_text(cx + 10, VALUE_Y + 24, unit_str, WHITE, BLACK, size=2)

    def update_bar(self, value, max_val, color):
        w_inner = SCREEN_W - 40
        self.d.draw_rect(18, BAR_Y, w_inner + 4, BAR_H, WHITE)
        self.d.fill_rect(20, BAR_Y + 2, w_inner, BAR_H - 4, C_BAR_BG)
        fill_w = int((value / max_val) * w_inner) if max_val else 0
        fill_w = max(0, min(w_inner, fill_w))
        if fill_w > 0: self.d.fill_rect(20, BAR_Y + 2, fill_w, BAR_H - 4, color)

    def update_info(self, line1, line2):
        combined = line1 + '|' + line2
        if combined == self._last_info_str: return
        self._last_info_str = combined
        self.d.fill_rect(0, INFO_Y1, SCREEN_W, INFO_Y2 - INFO_Y1 + 15, BLACK)
        self.d.draw_text_center(INFO_Y1, line1, WHITE, BLACK, size=1)
        self.d.draw_text_center(INFO_Y2, line2, GRAY, BLACK, size=1)

    # ──────────────────────────────────────────────────
    # Mode Displays
    # ──────────────────────────────────────────────────
    def show_volt(self, volt, min_v, max_v):
        self.update_value(f'{volt:5.2f}', 'V', C_VOLT)
        self.update_bar(volt, 30.0, C_VOLT)
        bat_pct = ""
        if 2.5 <= volt <= 4.3: cells, vmin, vmax = 1, 3.2, 4.2
        elif 4.3 < volt <= 8.5: cells, vmin, vmax = 2, 6.4, 8.4
        elif 8.5 < volt <= 12.7: cells, vmin, vmax = 3, 9.6, 12.6
        elif 12.7 < volt <= 16.9: cells, vmin, vmax = 4, 12.8, 16.8
        elif 16.9 < volt <= 21.1: cells, vmin, vmax = 5, 16.0, 21.0
        elif 21.1 < volt <= 25.5: cells, vmin, vmax = 6, 19.2, 25.2
        else: cells = 0
            
        if cells > 0:
            pct = max(0, min(100, int((volt - vmin) / (vmax - vmin) * 100)))
            bat_pct = f"Battery: {pct}% ({cells}S LiPo)"
            
        self.update_info(f"Min: {min_v:5.2f}V      Max: {max_v:5.2f}V", bat_pct)

    def show_diode(self, result_type, vf, ohms=0.0):
        if ohms == 0.0: ohm_str = "0.00 Ohm"
        elif ohms == float('inf'): ohm_str = "OPEN CKT"
        elif ohms < 1000: ohm_str = f"{ohms:.1f} Ohm"
        elif ohms < 1000000: ohm_str = f"{(ohms/1000):.2f} kOhm"
        else: ohm_str = f"{(ohms/1000000):.2f} MOhm"

        if result_type == 'OPEN':
            ana_deger, birim, renk = "--.--", "", GRAY
            alt_bilgi1, alt_bilgi2 = "OPEN CIRCUIT", "Probes Floating"
        elif result_type == 'SHORT':
            ana_deger, birim, renk = "0.00", "Ohm", RED
            alt_bilgi1, alt_bilgi2 = "SHORT CIRCUIT", "Buzzer Active"
        elif result_type == 'RESISTOR':
            parts = ohm_str.split()
            ana_deger, birim, renk = parts[0], parts[1] if len(parts) > 1 else '', CYAN
            alt_bilgi1, alt_bilgi2 = "RESISTANCE VALUE", f"Measured Vout: {vf:.3f}V"
        elif result_type == 'DIODE_OR_RES':
            ana_deger, birim, renk = f"{vf:.3f}", "Vf", C_DIODE
            alt_bilgi1, alt_bilgi2 = "DIODE / LED (Or Resistor)", f"Equiv Res: {ohm_str}"
        else:
            ana_deger, birim, renk = "---", "", GRAY
            alt_bilgi1, alt_bilgi2 = "UNKNOWN", ""

        self.update_value(ana_deger, birim, renk)
        self.update_bar(vf if result_type in ('DIODE_OR_RES', 'RESISTOR') else 0, 3.3, renk)
        self.update_info(alt_bilgi1, alt_bilgi2)

    def show_resistance_only(self, ohms, vf):
        if ohms == float('inf'):
            ana_deger, birim, renk = "OPEN", "", GRAY
            alt_info = "Probes Floating (Rx > 5M)"
        elif ohms == 0.0:
            ana_deger, birim, renk = "0.00", "Ohm", RED
            alt_info = "Short Circuit / 0 Ohm"
        elif ohms < 1000:
            ana_deger, birim, renk = f"{ohms:.1f}", "Ohm", CYAN
            alt_info = f"Vout: {vf:.3f}V | Ref: 1k"
        elif ohms < 1_000_000:
            ana_deger, birim, renk = f"{(ohms/1000):.2f}", "kOhm", CYAN
            alt_info = f"Vout: {vf:.3f}V | Ref: 1k"
        else:
            ana_deger, birim, renk = f"{(ohms/1_000_000):.2f}", "MOhm", CYAN
            alt_info = f"Vout: {vf:.3f}V | Ref: 1k"

        self.update_value(ana_deger, birim, renk)
        self.update_bar(min(ohms, 10000), 10000, CYAN)
        self.update_info("RESISTANCE MODE (1k Ref)", alt_info)

    def show_continuity(self, is_short, vf, ohms):
        if is_short:
            self.update_value("SHORT", "", RED)
            self.update_bar(3.3, 3.3, RED)
            self.update_info("CONTINUITY (Buzzer ON)", f"Resistance: {ohms:.1f} Ohm")
        else:
            self.update_value("OPEN", "", GRAY)
            self.update_bar(0, 3.3, GRAY)
            self.update_info("NO CONTINUITY", "Open Circuit")

    def show_led_test(self, rtype, vf):
        if rtype == 'OPEN':
            self.update_value("--.--", "", GRAY)
            self.update_bar(0, 3.3, GRAY)
            self.update_info("NO LED DETECTED", "Check Anode / Cathode polarity")
        elif rtype == 'SHORT':
            self.update_value("0.00", "V", RED)
            self.update_bar(3.3, 3.3, RED)
            self.update_info("SHORT CIRCUIT", "LED shorted or reversed")
        else:
            color_hint = "Red/Yellow LED" if vf < 2.0 else ("Green/Blue LED" if vf < 2.8 else "White LED/Diode")
            self.update_value(f"{vf:.3f}", "Vf", C_DIODE)
            self.update_bar(vf, 3.3, C_DIODE)
            self.update_info(f"LED ACTIVE ({color_hint})", f"Forward Voltage: {vf:.3f}V")

    def show_current(self, amps, volts):
        self.update_value(f'{amps:5.2f}', 'A', C_CURRENT)
        self.update_bar(abs(amps), 5.0, C_CURRENT)
        power = abs(amps * volts)
        self.update_info(f"Current: {amps:5.2f} A", f"Power: {power:6.2f} W (V={volts:.1f}V)")

    def show_splash(self):
        self.d.fill_screen(C_HEADER)
        self.d.draw_text_center(65,  'PicoMeter Touch', WHITE, C_HEADER, size=3)
        self.d.draw_text_center(105, 'developed by MAKERIO', YELLOW, C_HEADER, size=1)
        self.d.draw_text_center(150, 'Starting System...', CYAN, C_HEADER, size=1)


    # ──────────────────────────────────────────────────
    # Touch Detection Zones
    # ──────────────────────────────────────────────────
    def detect_touch_zone(self, tx, ty):
        # HOLD butonu (Sağ üst köşe geniş alan: X: 220-320, Y: 0-60)
        if 0 <= ty <= 60 and 220 <= tx <= 320: return 'HOLD'
        
        # Alt menü butonları (DC VOLT, COMPONENT, CURRENT)
        if 150 <= ty <= 240:
            if 0 <= tx <= 107: return 'VOLT'
            elif 108 <= tx <= 213: return 'DIODE'
            elif 214 <= tx <= 320: return 'CURRENT'
        return None


    def detect_component_menu_touch(self, tx, ty, page):
        if 185 <= ty <= 240:
            if 0 <= tx <= 130: return 'BACK'
            if 190 <= tx <= 320: return 'NEXT_PAGE' if page == 1 else 'PREV_PAGE'

        if 35 <= ty <= 185:
            row = -1
            if 35 <= ty <= 82: row = 0
            elif 85 <= ty <= 132: row = 1
            elif 135 <= ty <= 182: row = 2

            col = -1
            if 5 <= tx <= 158: col = 0
            elif 160 <= tx <= 315: col = 1

            if row != -1 and col != -1:
                idx = (page - 1) * 6 + (row * 2 + col)
                if idx < 10: return f'COMP_{idx}'
        return None

    def detect_hw_warning_touch(self, tx, ty):
        if 180 <= ty <= 240 and 90 <= tx <= 230: return 'BACK'
        return None

    # ──────────────────────────────────────────────────
    # Screensaver (Two Eyes Animation)
    # ──────────────────────────────────────────────────
    def draw_screensaver_base(self):
        self.d.fill_screen(BLACK)
        self.d.draw_text_center(210, "Sleeping - Touch to Wake", DARKGRAY, BLACK, size=1)

    def draw_screensaver_eyes(self, look_direction='CENTER', blink=False):
        eyes = [(75, 70), (175, 70)]

        if blink:
            for ex, ey in eyes:
                self.d.fill_rect(ex, ey, 70, 80, BLACK)
                self.d.fill_rect(ex + 5, ey + 38, 60, 6, CYAN)
            return

        pupil_offsets = {
            'CENTER': (20, 25),
            'LEFT':   (6,  25),
            'RIGHT':  (34, 25),
            'UP':     (20, 12),
        }
        pox, poy = pupil_offsets.get(look_direction, (20, 25))

        for ex, ey in eyes:
            self.d.fill_rect(ex + 8, ey, 54, 80, CYAN)
            self.d.fill_rect(ex, ey + 8, 70, 64, CYAN)
            self.d.fill_rect(ex + 4, ey + 4, 62, 72, CYAN)

            self.d.fill_rect(ex + 10, ey + 4, 50, 72, WHITE)
            self.d.fill_rect(ex + 4, ey + 10, 62, 60, WHITE)

            px = ex + pox
            py = ey + poy
            self.d.fill_rect(px, py, 30, 32, BLACK)

            self.d.fill_rect(px + 4, py + 4, 8, 8, WHITE)
            self.d.fill_rect(px + 16, py + 18, 5, 5, WHITE)
